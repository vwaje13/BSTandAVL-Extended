This is an explanation of my Project 2

There are 2 functions you can test for the AVL tree.
Contains 'number' : checks if 'number' exists within the AVL tree
Add 'number' : adds 'number' to the AVL tree

Write these statements on new lines with any numbers and on a new line, type "End"
The system will then print out the time it took to calculate the functions you entered, the
memory space the AVL tree is taking, and the number of successful statements that you entered.